"""Offline article-level remeasurement and preprocessing round-trip control.

No model calls and no production code changes. Round trips are NOT translations.
"""
import json, sys, copy, csv
from pathlib import Path
from collections import Counter
from dataclasses import replace
from lxml import etree as E

P=Path(__file__).parent
ROOT=P.parent
sys.path.insert(0,str(ROOT))
from xinda.formats.xml_units import _serialize_unit, _rewrite_element
from xinda.formats.profiles import JATS_PROFILE

def read(p): return json.loads(p.read_text(encoding='utf8'))
def canonical(e):
    return (e.tag,tuple(sorted(e.attrib.items())),e.text or '',tuple((canonical(c),c.tail or '') for c in e if isinstance(c.tag,str)))
def tally(tree,roots,tags):
    result=Counter()
    for path in roots:
        for root in tree.xpath(path):
            for e in root.iter():
                if isinstance(e.tag,str) and E.QName(e).localname in tags:
                    key=(e.tag,tuple(sorted(e.attrib.items()))) if tags=={'xref','ext-link','uri','email'} else canonical(e)
                    result[(path,key)]+=1
    return result

groups={'xref':{'xref','ext-link','uri','email'},'formula':{'inline-formula','disp-formula'},'supsub':{'sup','sub'}}
rows=[]
for m in read(P/'manifest.json'):
    src=E.parse(str(ROOT/m['path']))
    units=read(P/'sources'/f"{m['id']}.json")['units']
    paths=[u['xpath'] for u in units]
    roots=[p for p in paths if not any(p.startswith(q+'/') for q in paths if p!=q)]
    targets={mode:E.parse(str(P/'runs'/m['id']/mode/'translation.xml')) for mode in ['placeholder','raw_xml','plain']}
    for name,extra in [('roundtrip_original',frozenset()),('roundtrip_supsub',frozenset({'sup','sub'}))]:
        profile=replace(JATS_PROFILE,suppress_nested_units=False,preserve_tags=JATS_PROFILE.preserve_tags|extra)
        tree=copy.deepcopy(src)
        for u in sorted(units,key=lambda x:x['xpath'].count('/')):
            original=src.xpath(u['xpath'])[0]
            ph,sc,text=_serialize_unit(original,profile)
            for a,b in sc.items(): text=text.replace(a,b)
            el=tree.xpath(u['xpath'])[0]
            attrs=dict(el.attrib);tail=el.tail
            el.clear();el.attrib.update(attrs);el.tail=tail
            _rewrite_element(el,text,ph,profile)
        targets[name]=tree
    for mode,target in targets.items():
        row={'id':m['id'],'mode':mode}
        for k,tags in groups.items():
            a=tally(src,roots,tags);b=tally(target,roots,tags)
            row[k+'_source']=sum(a.values());row[k+'_matched']=sum((a&b).values())
        rows.append(row)

summary={}
for mode in targets:
    rr=[r for r in rows if r['mode']==mode];summary[mode]={}
    for k in groups:
        eligible=[r for r in rr if r[k+'_source']]
        summary[mode][k]={'source':sum(r[k+'_source'] for r in rr),'matched':sum(r[k+'_matched'] for r in rr),'eligible_articles':len(eligible),'all_matched_articles':sum(r[k+'_source']==r[k+'_matched'] for r in eligible)}
prior=list(csv.DictReader((P/'逐篇结果.csv').open(encoding='utf-8-sig')))
for r in rows:
    if r['mode'].startswith('roundtrip'):continue
    previous=next(x for x in prior if x['id']==r['id'] and x['mode']==r['mode'])
    assert all(r[k]==int(previous[k]) for k in r if k not in ['id','mode']),r
out={'design':'Post hoc offline source-output remeasurement; identity round-trip controls exclude model inference and do not establish translation quality. Sup/sub protected contents are retained verbatim. Original 50 sources and unit paths fixed.','summary':summary,'rows':rows,'previous_counts_verified':True}
(P/'篇级与预处理核验.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
