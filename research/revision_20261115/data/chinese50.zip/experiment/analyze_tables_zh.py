from pathlib import Path
from lxml import etree as E
import json,csv,re,collections
P=Path(__file__).parent;ROOT=P.parent
ms=json.loads((P/'manifest.json').read_text(encoding='utf8'));rows=[]
def shape(e):return tuple(tuple((c.tag,c.get('rowspan','1'),c.get('colspan','1')) for c in r if c.tag in ('td','th')) for r in e.xpath('.//tr'))
for m in ms:
 src=E.parse(str(ROOT/m['path']));tables=src.xpath('//body//table-wrap//table[not(ancestor::table)]')
 for mode in ['placeholder','raw_xml','plain']:
  dst=E.parse(str(P/'runs'/m['id']/mode/'translation.xml'));r={'id':m['id'],'mode':mode,'tables':len(tables),'table_shape_matched':0,'chinese_cells_source':0,'chinese_cells_retained':0,'cells_missing':0}
  for tb in tables:
   es=dst.xpath(src.getpath(tb));r['table_shape_matched']+=bool(es) and shape(tb)==shape(es[0])
   for cell in tb.xpath('.//td|.//th'):
    if not re.search('[一-鿿]',''.join(cell.itertext())):continue
    r['chinese_cells_source']+=1;cs=dst.xpath(src.getpath(cell));r['cells_missing']+=not bool(cs)
    r['chinese_cells_retained']+=bool(cs) and bool(re.search('[一-鿿]',''.join(cs[0].itertext())))
  rows.append(r)
out={}
for mode in ['placeholder','raw_xml','plain']:
 rr=[r for r in rows if r['mode']==mode];out[mode]={k:sum(r[k] for r in rr) for k in rr[0] if isinstance(rr[0][k],int)}
(P/'table_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with (P/'中文表格逐篇核验.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(out,ensure_ascii=False,indent=2))
