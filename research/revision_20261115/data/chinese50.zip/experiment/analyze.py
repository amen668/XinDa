import json,csv,re,sys,hashlib,math
from pathlib import Path
from collections import Counter,defaultdict
from lxml import etree as E
P=Path(__file__).parent;ROOT=P.parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def save(name,x): (P/name).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
def csvsave(name,rows):
 with (P/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def canonical(e):return (e.tag,tuple(sorted(e.attrib.items())),e.text or '',tuple((canonical(c),c.tail or '') for c in e if isinstance(c.tag,str)))
def metric(t,paths,tags,content=False):
 out=Counter()
 for path in paths:
  els=t.xpath(path)
  if not els:continue
  for e in els[0].iter():
   if isinstance(e.tag,str) and e.tag.split('}')[-1] in tags:
    key=canonical(e) if content else (e.tag,tuple(sorted(e.attrib.items())))
    out[(path,key)]+=1
 return out
def chinese(s):return bool(re.search('[一-鿿]',s))
manifest=read(P/'manifest.json');rows=[];audit=[]
for m in manifest:
 s=read(P/'sources'/f"{m['id']}.json");src=E.parse(str(ROOT/m['path']));paths=[u['xpath'] for u in s['units']]
 roots=[p for p in paths if not any(p.startswith(q+'/') for q in paths if p!=q)]
 groups={'xref':({'xref','ext-link','uri','email'},False),'formula':({'inline-formula','disp-formula'},True),'supsub':({'sup','sub'},True)}
 # Original text nodes not inside any selected translation unit, restricted to science content.
 uncovered=[]
 for e in src.xpath('//body | //abstract | //title-group'):
  for n in e.xpath('.//text()'):
   if not chinese(str(n)):continue
   owner=n.getparent();owner=owner.getparent() if n.is_tail else owner
   p=src.getpath(owner)
   if not any(p==q or p.startswith(q+'/') for q in paths):uncovered.append((p,str(n)))
 audit.append({'id':m['id'],'uncovered_chinese_nodes':uncovered,'kinds':dict(Counter(u['kind'] for u in s['units']))})
 for mode in ('placeholder','raw_xml','plain'):
  d=P/'runs'/m['id']/mode
  if not (d/'result.json').exists():continue
  r=read(d/'result.json');r['errors']=';'.join(r['errors']);t=E.parse(str(d/'translation.xml'))
  for name,(tags,content) in groups.items():
   a=metric(src,roots,tags,content);b=metric(t,roots,tags,content)
   r[name+'_source']=sum(a.values());r[name+'_matched']=sum((a&b).values())
  a=[canonical(e) for e in src.xpath('//ref-list')];b=[canonical(e) for e in t.xpath('//ref-list')];r['bibliography_unchanged']=a==b
  # Check surviving output nodes, stripping protected elements before residual-language screening.
  residual=0;missing=0
  for u in s['units']:
   els=t.xpath(u['xpath'])
   if not els:missing+=1;continue
   el=E.fromstring(E.tostring(els[0],with_tail=False))
   for node in list(el.iterdescendants()):
    if isinstance(node.tag,str) and node.tag.split('}')[-1] in {'xref','ext-link','uri','email','inline-formula','disp-formula','label','inline-graphic'}:
     if node.getparent() is not None:
      tail=node.tail;parent=node.getparent();prev=node.getprevious();parent.remove(node)
      if tail:
       if prev is None:parent.text=(parent.text or '')+tail
       else:prev.tail=(prev.tail or '')+tail
   residual+=chinese(''.join(el.itertext()))
  r['output_chinese_units']=residual;r['missing_output_nodes']=missing
  r['all_returned']=r['returned']==r['n'];r['all_applied']=r['applied']==r['n']
  rows.append(r)
csvsave('逐篇结果.csv',rows);save('scope_audit.json',audit)
summary={}
for mode in ('placeholder','raw_xml','plain'):
 rr=[x for x in rows if x['mode']==mode];s={k:sum(x[k] for x in rr) for k in rr[0] if isinstance(rr[0][k],(int,float,bool))};s['articles']=len(rr);summary[mode]=s
save('summary.json',summary)
challenge=[]
for x in read(P/'challenge_results.json'):
 ans=json.loads(x['response']['choices'][0]['message']['content']);challenge.append({k:v for k,v in x.items() if k not in ('response','prompt')}|ans)
csvsave('受控命题逐项结果.csv',challenge)
cs={k:dict(Counter(x['verdict'] for x in challenge if x['condition']==k)) for k in sorted({x['condition'] for x in challenge})}
cs['articles']=len({x['pmcid'] for x in challenge});cs['source_sentences']=len({x['source'] for x in challenge});cs['overlap_fulltext']=len({x['pmcid'] for x in challenge}&{x['id'] for x in manifest});save('challenge_summary.json',cs)
# Numeric token experiment: independent unit pairs, one decimal that occurs once on both sides.
nums=[];decimal=re.compile(r'(?<![\d.])\d+\.\d+(?![\d.])')
for m in manifest:
 d=P/'runs'/m['id']/'placeholder'
 if not (d/'pairs.json').exists():continue
 for u in read(d/'pairs.json'):
  if not u['returned']:continue
  source=re.sub(r'\{\{[^{}]*\}\}','',u['source_protected']);target=re.sub(r'\{\{[^{}]*\}\}','',u['target'])
  options=[n for n in decimal.findall(source) if decimal.findall(source).count(n)==1 and decimal.findall(target).count(n)==1]
  if not options:continue
  n=options[0];pat=re.compile(r'(?<![\d.])'+re.escape(n)+r'(?![\d.])')
  for kind,repl in [('对照',n),('删除',''),('追加数字',n+'1')]:
   altered=pat.sub(lambda _:repl,target,count=1)
   nums.append(dict(pmcid=m['id'],unit_id=u['id'],number=n,condition=kind,substring_flag=n not in altered,boundary_flag=not bool(pat.search(altered)),source=source,target=altered))
grouped=defaultdict(list)
for x in nums:grouped[(x['pmcid'],x['unit_id'])].append(x)
keys=sorted(grouped,key=lambda k:hashlib.sha256(f'20261111|{k[0]}|{k[1]}'.encode()).hexdigest())[:200]
nums=[x for k in keys for x in grouped[k]]
csvsave('数值扰动逐项结果.csv',nums)
ns={c:{'n':sum(x['condition']==c for x in nums),'substring_flag':sum(x['substring_flag'] for x in nums if x['condition']==c),'boundary_flag':sum(x['boundary_flag'] for x in nums if x['condition']==c)} for c in ['对照','删除','追加数字']};ns['articles']=len({x['pmcid'] for x in nums});save('numeric_summary.json',ns)
print(json.dumps({'completed':len(rows),'summary':summary,'challenge':cs,'numeric':ns,'uncovered_nodes':sum(len(x['uncovered_chinese_nodes']) for x in audit)},ensure_ascii=False,indent=2))
